When project updates occur:

- Review if the changes affect core features, game mechanics, or technical implementation
- Update README.md if new features are added, existing features are modified, or game balance changes
- Keep the README concise and focused on user-facing information
- Ensure technical stack information remains accurate
- Update usage instructions if gameplay mechanics change
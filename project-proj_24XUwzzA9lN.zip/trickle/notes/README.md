# TikTok Boss Fight - Live Stream Interactive Game

An engaging boss fight game designed for TikTok live streams where viewers can send virtual gifts to deal damage to a boss character.

## Features

- **Interactive Boss Fight**: Real-time boss health tracking with visual feedback
- **Gift System**: 8 different gift types with varying damage values (100-5000 HP)
- **Leaderboard**: Top 10 damage dealers displayed in real-time
- **Visual Effects**: Animated damage numbers and health bar
- **Username Tracking**: Players can enter their TikTok username to appear on the leaderboard
- **Game Reset**: Start a new boss fight after defeating the current one
- **Session History**: Automatically saves completed games with winner, duration, and top players
- **Database Integration**: Uses Trickle database to persist game session data

## Gift Types & Damage

- 🌹 Rose: 100 HP
- ❤️ Heart: 250 HP
- ⭐ Star: 500 HP
- 💎 Diamond: 1,000 HP
- 👑 Crown: 1,500 HP
- 🚀 Rocket: 2,000 HP
- 🦁 Lion: 3,000 HP
- 🌌 Galaxy: 5,000 HP

## Game Mechanics

1. Boss starts with 10,000 HP
2. Players enter their username and select gifts to attack
3. Each gift deals instant damage to the boss
4. Leaderboard tracks total damage per player
5. Boss is defeated when health reaches 0
6. Game can be reset to start a new boss fight

## Technical Stack

- React 18 for UI components
- TailwindCSS for styling
- Lucide icons for UI elements
- Trickle Database for session persistence
- Responsive design for mobile and desktop

## Usage

Perfect for TikTok live streamers who want to engage their audience with an interactive gaming experience. Viewers can participate by "sending gifts" to collectively defeat the boss.
function getGiftList() {
  return [
    { id: 1, name: 'Rose', icon: '🌹', damage: 100 },
    { id: 2, name: 'Heart', icon: '❤️', damage: 250 },
    { id: 3, name: 'Star', icon: '⭐', damage: 500 },
    { id: 4, name: 'Diamond', icon: '💎', damage: 1000 },
    { id: 5, name: 'Crown', icon: '👑', damage: 1500 },
    { id: 6, name: 'Rocket', icon: '🚀', damage: 2000 },
    { id: 7, name: 'Lion', icon: '🦁', damage: 3000 },
    { id: 8, name: 'Galaxy', icon: '🌌', damage: 5000 }
  ];
}